// Send a message
PUBNUB.publish({ channel : 'chat', message : "hello!" })