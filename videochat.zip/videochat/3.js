// Receive messages
PUBNUB.subscribe({ channel : 'chat', message : fun })